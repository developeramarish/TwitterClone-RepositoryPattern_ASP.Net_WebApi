﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TwitterClone_API.API_QueryModels;
using TwitterClone_API.EntityFramework;
using TwitterClone_API.RepositoryInterfaces;
using TwitterClone_API.CustomEntities;

namespace TwitterClone_API.Repositories
{
    public class PersonRepository : IPersonRepository
    {
        public MemberCount CountFollowersAndFollowees(int userId)
        {
            using (TwitterCloneDBEntities context = new EntityFramework.TwitterCloneDBEntities())
            {
                try
                {
                    MemberCount obj = new CustomEntities.MemberCount();

                    obj.FollowerCount = (from f in context.Followers
                                         where f.FollowingId == userId
                                         select f.FollowingId).Count();

                    obj.FollowingCount = (from f in context.Followers
                                          where f.UserId == userId
                                          select f.UserId).Count();
                    return obj;
                }
                catch
                {
                    throw new Exception("Failed to fetch the count of Followers and Followees");
                }
            }
        }

        public void CreatePerson(Person person)
        {
            using (TwitterCloneDBEntities context = new EntityFramework.TwitterCloneDBEntities())
            {
                try
                {
                    context.People.Add(person);
                    context.SaveChanges();
                }
                catch
                {
                   throw new Exception("Failed to create your profile");                  
                }
            }
        }

        public void DeleteAccount(int userId)
        {
            using (TwitterCloneDBEntities context = new EntityFramework.TwitterCloneDBEntities())
            {
                try
                {
                    Person person = context.People.SingleOrDefault(x => x.Id == userId);
                    context.People.Remove(person);
                    context.SaveChanges();
                }
                catch
                {
                    throw new Exception("Failed to delete your account");
                }
            }
        }

        public void EditProfile(Person peson)
        {
            using (TwitterCloneDBEntities context = new EntityFramework.TwitterCloneDBEntities())
            {
                try
                {
                    Person oldPerson = context.People.SingleOrDefault(x => x.Id == peson.Id);
                    context.People.Remove(oldPerson);
                    context.People.Add(peson);
                    context.SaveChanges();
                }
                catch
                {
                    throw new Exception("Failed to update your profile");
                }
            }
        }

        public void FollowUser(Follower follower)
        {           
            using (TwitterCloneDBEntities context = new EntityFramework.TwitterCloneDBEntities())
            {
                try
                {
                    context.Followers.Add(follower);
                    context.SaveChanges();
                }
                catch
                {
                    throw new Exception("Failed to follow your friend");
                }
            }
        }

        public Person LogIn(LogInQueryModel query)
        {
            using (TwitterCloneDBEntities context = new EntityFramework.TwitterCloneDBEntities())
            {
                context.Configuration.ProxyCreationEnabled = false; // To resolve the error
                Person loggedInUser = new EntityFramework.Person();
                try
                {
                    loggedInUser = context.People.FirstOrDefault(x=>x.UserName == query.UserName && x.Password == query.Password);
                    return loggedInUser;
                }
                catch
                {
                    throw new Exception("Failed to verify your credentials");
                }
            }
        }

        public List<Person> SearchUsers(string userName)
        {
            List<Person> searchResults = new List<Person>();
            using (TwitterCloneDBEntities context = new EntityFramework.TwitterCloneDBEntities())
            {
                context.Configuration.ProxyCreationEnabled = false; // To resolve the error

                try
                {
                    //searchResults = context.People.Where(x => x.UserName == userName).ToList();
                    searchResults= (from e in context.People
                     where e.UserName.ToLower().Contains(userName.ToLower())
                     select e).ToList();
                    return searchResults;
                }
                catch
                {
                    throw new Exception("Your search yielded no results");
                }
            }
        }
    }
}