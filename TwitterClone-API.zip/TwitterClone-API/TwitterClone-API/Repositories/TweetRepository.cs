﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Web;
using TwitterClone_API.EntityFramework;
using TwitterClone_API.RepositoryInterfaces;

namespace TwitterClone_API.Repositories
{
    public class TweetRepository : ITweetRepository
    {
        public void CreateTweet(Tweet tweet)
        {
            using (TwitterCloneDBEntities context = new EntityFramework.TwitterCloneDBEntities())
            {
                try
                {
                    context.Tweets.Add(tweet);
                    context.SaveChanges();
                }
                catch
                {
                    throw new Exception("Failed to post your tweet");
                }
            }
        }

        public void DeleteTweet(int Id)
        {
            using (TwitterCloneDBEntities context = new EntityFramework.TwitterCloneDBEntities())
            {
                try
                {
                    Tweet tweet = context.Tweets.SingleOrDefault(x => x.Id == Id);
                    context.Tweets.Remove(tweet);
                    context.SaveChanges();
                }
                catch
                {
                    throw new Exception("Failed to delete your tweet");
                }
            }
        }

        public void EditTweet(Tweet tweet)
        {
            using (TwitterCloneDBEntities context = new EntityFramework.TwitterCloneDBEntities())
            {
                try
                {
                    Tweet OldTweet = context.Tweets.FirstOrDefault(x => x.Id == tweet.Id);
                    context.Tweets.Remove(OldTweet);
                    context.Tweets.Add(tweet);
                    context.SaveChanges();
                }
                catch
                {
                    throw new Exception("Failed to update your tweet");
                }
            }
        }

        public List<Tweet> GetAllYourTweets(int userId)
        {
            List<Tweet> yourTweets = new List<Tweet>();
            using (TwitterCloneDBEntities context = new EntityFramework.TwitterCloneDBEntities())
            {
                context.Configuration.ProxyCreationEnabled = false; // To resolve the error
                try
                {
                    yourTweets = context.Tweets.Where(x => x.UserId == userId).ToList();
                    return yourTweets;
                }
                catch
                {
                    throw new Exception("Failed to fetch your tweets");
                }
            }
        }

        public List<Tweet> GetTweetsOfUsers(int userId)
        {
            List<Tweet> yourFriendsTweets = new List<Tweet>();
        
            using (TwitterCloneDBEntities context = new EntityFramework.TwitterCloneDBEntities())
            {
                context.Configuration.ProxyCreationEnabled = false; // To resolve the error
                try
                {
                    // Fetch the list of friends
                   var listOfFriends = from f in context.Followers
                                        where f.UserId == userId
                                        select f.FollowingId;

                    foreach(var item in listOfFriends)
                    {                       
                        yourFriendsTweets = (context.Tweets.Where(x => x.UserId == item)).ToList();                        
                    }

                    return yourFriendsTweets;
                }
                catch
                {
                    throw new Exception("Failed to fetch your friends' tweets");                    
                }
            }                
        }
    }
}