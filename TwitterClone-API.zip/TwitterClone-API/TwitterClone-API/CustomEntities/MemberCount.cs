﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TwitterClone_API.CustomEntities
{
    public class MemberCount
    {
        public int FollowerCount { get; set; }
        public int FollowingCount { get; set; }
    }
}