﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TwitterClone_API.EntityFramework;
using TwitterClone_API.API_QueryModels;
using TwitterClone_API.CustomEntities;

namespace TwitterClone_API.RepositoryInterfaces
{
    public interface IPersonRepository
    {
        void CreatePerson(Person peson);
        void EditProfile(Person peson);
        void DeleteAccount(int userId);
        void FollowUser(Follower follower);
        List<Person> SearchUsers(string userName);
        Person LogIn(LogInQueryModel query);
        MemberCount CountFollowersAndFollowees(int userId);
    }
}