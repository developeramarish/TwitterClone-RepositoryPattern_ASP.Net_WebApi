﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using TwitterClone_API.EntityFramework;
using TwitterClone_API.API_QueryModels;
using TwitterClone_API.RepositoryInterfaces;
using TwitterClone_API.Repositories;

namespace TwitterClone_API.Controllers
{
    public class TweetController : ApiController
    {
        public TweetController()
        {

        }

        static readonly ITweetRepository tweetRepository = new TweetRepository();

        private const string InvalidRequestMessage = "Invalid request";
        private const string TweetSuccessMessage = "Your tweet was posted succesfully !";
        private const string TweetErrorMessage = "Failed to post your tweet";
        private const string TweetEditSuccessfulMessage = "Your tweet was updated successfully !";
        private const string TweetEditErrorMessage = "Failed to update your tweet";
        private const string TweetDeleteSuccessfulMessage = "Your tweet was deleted successfully !";
        private const string TweetDeleteErrorMessage = "Failed to delete your tweet";
        private const string GetYourTweetsFailedMessage = "Failed to fetch your tweets";
        private const string GetTweetsOfUsersFailedMessage = "Failed to fetch tweets of your friends";

        [HttpPost]
        [Route("Tweet/PostTweet")]
        public IHttpActionResult PostTweet(Tweet tweet)
        {
            if (tweet == null)
            {
                return this.BadRequest(InvalidRequestMessage);
            }
            try
            {
                tweetRepository.CreateTweet(tweet);
                return this.Ok(TweetSuccessMessage);
            }
            catch
            {
                return this.BadRequest(TweetErrorMessage);
            }
        }

        [HttpPut]
        [Route("Tweet/EditTweet")]
        public IHttpActionResult EditTweet(Tweet tweet)
        {
            if (tweet == null)
            {
                return this.BadRequest(InvalidRequestMessage);
            }
            try
            {
                tweetRepository.EditTweet(tweet);
                return this.Ok(TweetEditSuccessfulMessage);
            }
            catch
            {
                return this.BadRequest(TweetEditErrorMessage);
            }
        }

        [HttpDelete]
        [Route("Tweet/DeleteTweet")]
        public IHttpActionResult DeleteTweet(int id)
        {
            if (id == 0)
            {
                return this.BadRequest(InvalidRequestMessage);
            }
            try
            {
                tweetRepository.DeleteTweet(id);
                return this.Ok(TweetDeleteSuccessfulMessage);
            }
            catch
            {
                return this.BadRequest(TweetDeleteErrorMessage);
            }
        }

        [HttpGet]
        [Route("Tweet/GetAllYourTweets")]
        public IHttpActionResult GetAllYourTweets(int userId)
        {
            if (userId == 0)
            {
                return this.BadRequest(InvalidRequestMessage);
            }
            try
            {
                var yourTweets = tweetRepository.GetAllYourTweets(userId);

                if (yourTweets == null)
                {
                    return this.BadRequest(GetYourTweetsFailedMessage);
                }
                return this.Ok(yourTweets);
            }
            catch
            {
                return this.BadRequest(GetYourTweetsFailedMessage);
            }
        }

        [HttpGet]
        [Route("Tweet/GetTweetsOfUsers")]
        public IHttpActionResult GetTweetsOfUsers(int userId)
        {
            if (userId == 0)
            {
                return this.BadRequest(InvalidRequestMessage);
            }
            try
            {
                var othersTweets = tweetRepository.GetTweetsOfUsers(userId);

                if (othersTweets == null)
                {
                    return this.BadRequest(GetTweetsOfUsersFailedMessage);
                }
                return this.Ok(othersTweets);
            }
            catch
            {
                return this.BadRequest(GetTweetsOfUsersFailedMessage);
            }
        }
    }
}

