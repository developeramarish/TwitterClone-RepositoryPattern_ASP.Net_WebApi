﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using TwitterClone_API.EntityFramework;
using TwitterClone_API.API_QueryModels;
using TwitterClone_API.RepositoryInterfaces;
using TwitterClone_API.Repositories;
using TwitterClone_API.CustomEntities;

namespace TwitterClone_API.Controllers
{

    public class PersonController : ApiController
    {
        public PersonController()
        {

        }

        static readonly IPersonRepository personRepository = new PersonRepository();

        private const string SignUpSuccesfullMessage = "Sign-Up succesful !";
        private const string SignUpFailedMessage = "Sign-Up failed. Please try out a different Username";
        private const string InvalidRequestMessage = "Invalid request";
        private const string EditProfileSuccesfullMessage = "User profile updated succesfully !";
        private const string EditProfileFailedMessage = "User profile update failed";
        private const string DeleteAccountSuccessful = "User accout has been deleted successfully !";
        private const string DeleteAccountFailed = "Failed to delete the user's account";
        private const string FollowSuccessfulMessage = "Succesfully followed !";
        private const string FollowFailedMessage = "Failed to follow the user";
        private const string NoResultsMessage = "Search criteria did not yield any results";
        private const string SearchFailedMessage = "User search failed";
        private const string SignInFailedMessage = "Invalid credentials. Sign-In failed";
        private const string MemberCountFailedMessage = "Failed to fetch the count of Followers and Followees";

        [HttpPost]
        [Route("Person/SignUp")]
        public IHttpActionResult SignUp([FromBody]Person person) // Registering a user to TwitterClone
        {
            if (person == null)
            {
                return this.BadRequest(InvalidRequestMessage);
            }
            try
            {
                personRepository.CreatePerson(person);
                return this.Ok(new { StatusCode = HttpStatusCode.OK, ResponseMessage = SignUpSuccesfullMessage });
            }
            catch
            {
                return this.BadRequest(SignUpFailedMessage);
            }
        }

        [HttpPost]
        [Route("Person/LogIn")]
        public IHttpActionResult LogIn(LogInQueryModel query)
        {
            if (query == null)
            {
                return this.BadRequest(InvalidRequestMessage);
            }
            try
            {
                var logInResult = personRepository.LogIn(query);

                if (logInResult == null)
                {
                    return this.BadRequest(SignInFailedMessage);
                }
                return this.Ok(logInResult);
            }
            catch
            {
                return this.BadRequest(SignInFailedMessage);
            }
        }

        [HttpPut]
        [Route("Person/EditProfile")]
        public IHttpActionResult EditProfile([FromBody]Person person) // Edit user's profile
        {
            if (person == null)
            {
                return this.BadRequest(InvalidRequestMessage);
            }
            try
            {
                personRepository.EditProfile(person);
                return this.Ok(new { StatusCode = HttpStatusCode.OK, ResponseMessage = EditProfileSuccesfullMessage });
            }
            catch
            {
                return this.BadRequest(EditProfileFailedMessage);
            }


        }

        [HttpDelete]
        [Route("Person/DeleteAccount")]
        public IHttpActionResult DeleteAccount([FromUri]int userId) // Delete user's account and tweets
        {
            if (userId == 0)
            {
                return this.BadRequest(InvalidRequestMessage);
            }

            try
            {
                personRepository.DeleteAccount(userId);
                return this.Ok(new { StatusCode = HttpStatusCode.OK, ResponseMessage = DeleteAccountSuccessful });
            }
            catch
            {
                return this.BadRequest(DeleteAccountFailed);
            }
        }

        [HttpPost]
        [Route("Person/FollowUser")]
        public IHttpActionResult FollowUser(Follower follower)
        {
            if (follower == null)
            {
                return this.BadRequest(InvalidRequestMessage);
            }
            try
            {
                personRepository.FollowUser(follower);
                return this.Ok(new { StatusCode = HttpStatusCode.OK, ResponseMessage = FollowSuccessfulMessage });
            }
            catch
            {
                return this.BadRequest(FollowFailedMessage);
            }
        }

        [HttpGet]
        [Route("Person/SearchUser")]
        public IHttpActionResult SearchUser(string userName)
        {
            if (userName == null || userName == "")
            {
                return this.BadRequest(InvalidRequestMessage);
            }
            try
            {
                var searchResults = personRepository.SearchUsers(userName);

                if (searchResults == null)
                {
                    return this.BadRequest(NoResultsMessage);
                }
                return this.Ok(searchResults);
            }
            catch
            {
                return this.BadRequest(SearchFailedMessage);
            }
        }

        [HttpGet]
        [Route("Person/CountFollowersAndFollowees")]
        public IHttpActionResult CountFollowersAndFollowees(int userId)
        {
            if (userId == 0)
            {
                return this.BadRequest(InvalidRequestMessage);
            }
            try
            {
                MemberCount obj = new MemberCount();
                obj = personRepository.CountFollowersAndFollowees(userId);
                return this.Ok(obj);
            }
            catch
            {
                return this.BadRequest(MemberCountFailedMessage);
            }
        }
    }
}
