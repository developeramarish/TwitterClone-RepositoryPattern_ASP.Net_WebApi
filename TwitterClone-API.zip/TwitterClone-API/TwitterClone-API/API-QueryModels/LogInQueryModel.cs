﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TwitterClone_API.API_QueryModels
{
    public class LogInQueryModel
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}