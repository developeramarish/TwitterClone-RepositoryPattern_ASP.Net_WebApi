﻿(function () {
    //This file contains all the Web-Api constants
    angular
        .module('TwitterCloneApp')
        .constant('apiurls', {
            apiDomain: ''            
        })

})();