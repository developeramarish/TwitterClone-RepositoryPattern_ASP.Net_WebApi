﻿/// <reference path="components/Contact/contact.html" />
(function () {
    //Using ui-router instead of ngRouter
    angular
        .module('TwitterCloneApp')
        .config(['$stateProvider', '$urlRouterProvider', '$locationProvider', TwitterCloneRoute]);

    function TwitterCloneRoute($stateProvider, $urlRouterProvider, $locationProvider) {
        $urlRouterProvider.otherwise('/');

    }
})();