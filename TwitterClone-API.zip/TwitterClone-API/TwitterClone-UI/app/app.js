﻿(function () {

    // Setting or Defining of TemplateSellingApp and injecting all its dependencies
    angular.module('TwitterCloneApp', ['ui.router']);

})();