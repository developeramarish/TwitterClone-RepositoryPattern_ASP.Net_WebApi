﻿//Code to make the LogIn state as the default state
var app = angular.module('TwitterCloneApp')
.run(['$state', function ($state) {
    $state.transitionTo('login');
}])
