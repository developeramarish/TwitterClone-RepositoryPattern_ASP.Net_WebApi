﻿(function () {
    angular
        .module('TwitterCloneApp')
        .factory('AppService', ['$http', 'apiurls', TwitterCloneService]);

    function TwitterCloneService($http, apiurls) {

      
    };

})();