﻿(function () {

	// Registering a controller as a named function (instead of anonymous function)
    angular
        .module('TwitterCloneApp')
        .controller('TwitterCloneController', ['$rootScope', '$scope', '$state', 'TwitterCloneService', TwitterCloneController]);

    function TwitterCloneController($rootScope, $scope, $state, TwitterCloneService) {
      
    };

})();