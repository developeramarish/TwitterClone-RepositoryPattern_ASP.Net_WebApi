﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TwitterClone_Entities;
using TwitterClone_RepositoryInterfaces;
using TwitterClone_APIModels;

namespace TwitterClone_Repository
{
    public class PersonRepository : IPersonRepository
    {
        public void CreatePerson(Person peson)
        {
            throw new NotImplementedException();
        }

        public void DeleteAccount(int userId)
        {
            throw new NotImplementedException();
        }

        public void EditProfile(Person peson)
        {
            throw new NotImplementedException();
        }

        public void FollowUser(int userId, int followerUserId)
        {
            throw new NotImplementedException();
        }

        public Person LogIn(LogInQueryModel query)
        {
            throw new NotImplementedException();
        }

        public List<Person> SearchUsers(string userName)
        {
            throw new NotImplementedException();
        }
    }
}
