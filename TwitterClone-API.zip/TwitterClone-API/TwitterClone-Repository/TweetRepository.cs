﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TwitterClone_Entities;
using TwitterClone_RepositoryInterfaces;
namespace TwitterClone_Repository
{
    public class TweetRepository : ITweetRepository
    {
        //private TwitterCloneDBEntities context;
        //public TweetRepository(TwitterCloneDBEntities context)
        //{
        //    this.context = context;
        //}
        public void CreateTweet(Tweet tweet)
        {
            throw new NotImplementedException();
        }

        public void DeleteTweet(int Id)
        {
            throw new NotImplementedException();
        }

        public void EditTweet(Tweet tweet)
        {
            throw new NotImplementedException();
        }

        public List<Tweet> GetAllYourTweets(int userId)
        {
            throw new NotImplementedException();
        }

        public List<Tweet> GetTweetsOfUsers(int userId)
        {
            throw new NotImplementedException();
        }

        //private bool disposed = false;

        //protected virtual void Dispose(bool disposing)
        //{
        //    if (!this.disposed)
        //    {
        //        if (disposing)
        //        {
        //            context.Dispose();
        //        }
        //    }
        //    this.disposed = true;
        //}

        //public void Dispose()
        //{
        //    Dispose(true);
        //    GC.SuppressFinalize(this);
        //}
    }
}
