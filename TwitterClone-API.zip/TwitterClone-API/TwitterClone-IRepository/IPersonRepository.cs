﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TwitterClone_Entities;
using TwitterClone_APIModels;

namespace TwitterClone_RepositoryInterfaces
{
    public interface IPersonRepository 
    {
        void CreatePerson(Person peson);
        void EditProfile(Person peson);
        void DeleteAccount(int userId);
        void FollowUser(int userId, int followerUserId);
        List<Person> SearchUsers(string userName);
        Person LogIn(LogInQueryModel query);
    }
}
