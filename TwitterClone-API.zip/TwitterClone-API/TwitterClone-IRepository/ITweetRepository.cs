﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TwitterClone_Entities;

namespace TwitterClone_RepositoryInterfaces
{
    public interface ITweetRepository 
    {
        void CreateTweet(Tweet tweet);
        void EditTweet(Tweet tweet);
        void DeleteTweet(int Id);
        List<Tweet> GetTweetsOfUsers(int userId);
        List<Tweet> GetAllYourTweets(int userId);
    }
}
